#!/bin/bash

mkdir ../$1

wget http://download.geonames.org/export/dump/$1.zip 
unzip $1.zip ../$1/$1.txt
rm $1.zip

wget http://download.geonames.org/export/zip/$1.zip
unzip -d pc $1.zip $1.txt 
mv pc/$1.txt ../$1/$1_postcodes.txt
rm $1.zip




